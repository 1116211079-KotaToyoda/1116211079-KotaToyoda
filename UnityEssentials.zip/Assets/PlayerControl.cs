using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class PlayerControl : MonoBehaviour
{
    // Start is called before the first frame update
    private Transform _playerController;
    private CapsuleCollider2D _capsuleCollider;
    private Vector3 _playerLeft;
    private ContactFilter2D _contactFilter;
    private playerObjectDetection _onionDetection;
    private CookerDetection _cookerDetection;
    private DishDetection _dishDetection;
    private ServiceCounterDetection _serviceCounterDetection;
    
    private SpriteRenderer _spriteRenderer;
    
    private bool _pickUpAllowed;
    private bool _hasOnion;
    private bool _hasDish;
    private bool _hasCookedMeal;

    private Vector2 _lookDirection;
    private float _rayDistance;
    
    private ItemManagement _itemManager;
    List<RaycastHit2D> hits = new List<RaycastHit2D>();
    private ScoreBoardBehaviour _scoreBoard;
    
    [SerializeField] private float playerSpeed = 2.0f;
    
    
    [SerializeField] private float horizontalRayDistance = 0.5f;
    [SerializeField] private float verticalRayDistance = 1f;

    private int _layerMask;
    private int _tablelayerMask;
    void Start()
    {
        _playerController = GetComponent<Transform>();
        _capsuleCollider = GetComponent<CapsuleCollider2D>();
        _onionDetection = GetComponent<playerObjectDetection>();
        _spriteRenderer = GetComponent<SpriteRenderer>();
        _cookerDetection = GetComponent<CookerDetection>();
        _dishDetection = GetComponent<DishDetection>();
        _serviceCounterDetection = GetComponent<ServiceCounterDetection>();
        _itemManager = GetComponentInChildren<ItemManagement>();
        _scoreBoard = FindObjectOfType<ScoreBoardBehaviour>();
        
        _pickUpAllowed = true;
        _hasOnion = false;
        _hasDish = false;
        _hasCookedMeal = false;
        
        _layerMask = LayerMask.NameToLayer("Interactable");
        _tablelayerMask = LayerMask.NameToLayer("Table");
        
        _lookDirection = Vector2.zero;
        _contactFilter.SetLayerMask((1 << _layerMask) | (1 << _tablelayerMask));
        
    }

    // Update is called once per frame
    void Update()
    {
        Move();
        if (_onionDetection.IsNearOnion() || _cookerDetection.IsNearOven() || _dishDetection.GetDetected() || _serviceCounterDetection.GetDetected()) 
        {
            _spriteRenderer.color = Color.green;
            //
        }
        else
        {
            _spriteRenderer.color = Color.cyan;
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            putItem();
        }

        if (Input.GetKeyDown((KeyCode.F)))
        {
            getItem();
        }
        
        Debug.DrawRay(transform.position, _lookDirection * _rayDistance, Color.red);
        
    }

    private void FixedUpdate()
    {
        if (_lookDirection == Vector2.zero) return;
        detectObjectInFront();
    }


    private void Move()
    {
        if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.S))
        {
            _playerController.Translate(0, Input.GetAxis("Vertical") * Time.deltaTime * playerSpeed, 0);
            _lookDirection = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
        }

        if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.A))
        {
            _playerController.Translate(Input.GetAxis("Horizontal") * Time.deltaTime * playerSpeed, 0, 0);
            _lookDirection = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
            
        }


        if (!_lookDirection.Equals(Vector2.zero))
        {
            _lookDirection.Normalize();
        }
       
    }

    private void detectObjectInFront()
    {
        _rayDistance = _lookDirection.x != 0 ? horizontalRayDistance : verticalRayDistance;
        int numDetected = Physics2D.Raycast(transform.position, _lookDirection, _contactFilter, hits, _rayDistance);

        if (numDetected < 2) return;
        Debug.Log("somethings wrong... more than 2 object detected!");
    }

    private bool IsNearOven()
    {
        bool isNear = false;
        foreach (bool detected in _cookerDetection.GetDetected())
        {   
            //if false, continue the loop
            if (!detected) continue;
            isNear = true;
        }

        return isNear;
    }
    

    private void getItem()
    {
        
        if (_cookerDetection.IsNearOven() && _hasDish && _cookerDetection.GetOven().GetIsCooked())
        {
            Debug.Log("you have picked up an cooked Meal");
            _hasDish = false;
            _hasCookedMeal = true;
            _pickUpAllowed = false;
            _itemManager.DestroyHoldingItem();
            _itemManager.SetItemOnHand("CookedMeal");
            _cookerDetection.GetOven().ResetOnionInOven();
            return;
        }
        
        if (!_pickUpAllowed) return;
        
        if (_onionDetection.IsNearOnion())
        {
            Debug.Log("you have picked up an onion!");
            _pickUpAllowed = false;
            _hasOnion = true;
            _itemManager.SetItemOnHand("Onion");
            
            return;
        }

        if (_dishDetection.GetDetected())
        {
            Debug.Log("you have picked up a dish!");
            _pickUpAllowed = false;
            _hasDish = true;
            _itemManager.SetItemOnHand("Dish");
            return;
        }

        if (hits.Count > 0 && !_onionDetection.IsNearOnion() && !_serviceCounterDetection.GetDetected() &&
            !_cookerDetection.IsNearOven() && !_dishDetection.GetDetected())
        {
            GameObject table_collide = hits[0].collider.GameObject();
            GameObject itemDestroyed = table_collide.GetComponent<TableBehaviour>().RemoveItemFromTable(transform.position);

            if (itemDestroyed == null) return;
            Debug.Log("item destroyed: " + itemDestroyed);
            _itemManager.SetItemOnHand(itemDestroyed);
            if (itemDestroyed.name == "Onion(Clone)") _hasOnion = true;
            if(itemDestroyed.name == "Dish(Clone)") _hasDish = true;
            if(itemDestroyed.name == "CookedMeal(Clone)") _hasCookedMeal = true;
            _pickUpAllowed = false;
            Debug.Log("hasOnion: " + _hasOnion + "\nhasDish: " + _hasDish + "\nhasCookedMeal: " + _hasCookedMeal + "\npickUpAllowed:" + _pickUpAllowed);
        }
        
        
    }

    private void putItem()
    {
        //no item in hand, go back to loop
        if (_pickUpAllowed) return;
        if (_hasOnion && _cookerDetection.IsNearOven() && _cookerDetection.GetOven()?.GetOnionCounter() < 3)
        {
            //put onion into oven if possible (it needs to be less than 3 onions to activate this if statement)
            Debug.Log("you have put an onion in Oven!");
            _hasOnion = false;
            _pickUpAllowed = true;
            _itemManager.DestroyHoldingItem();
            _cookerDetection.GetOven().setOnionInOven();
            
            return;
        }

        if (_hasCookedMeal && _serviceCounterDetection.GetDetected())
        {
            Debug.Log("you have served a cooked Meal!!");
            _hasCookedMeal = false;
            _pickUpAllowed = true;
            _itemManager.DestroyHoldingItem();
            //increase score below
            _scoreBoard.IncrementScore();
            return;
        }

        if (!_onionDetection.IsNearOnion() && !_serviceCounterDetection.GetDetected() && !_cookerDetection.IsNearOven() && !_dishDetection.GetDetected() && hits.Count != 0)
        {
            //if not near interactable object, and raycast is detecting table object, set items on table
            GameObject table_collide = hits[0].collider.GameObject();
            if (table_collide.GetComponent<TableBehaviour>().checkNoItemOnTablePos(transform.position)) return;
            table_collide.GetComponent<TableBehaviour>().SetItemOnTable(_itemManager.GetItemHolding(),transform.position);
            _itemManager.DestroyHoldingItem();
            _pickUpAllowed = true;
            _hasOnion = false;
            _hasDish = false;
            _hasCookedMeal = false;
            Debug.Log("Hi from putItem");

        }
        
    }

    private void showHitInfo(List<RaycastHit2D> hits)
    {
        foreach (RaycastHit2D hit in hits)
        {
            Debug.Log("detected object: " + hit.collider.gameObject.name);
        }
    }

    public bool GetHasOnion()
    {
        return _hasOnion;
    }

    public Vector2 GetLookingDirection()
    {
        return _lookDirection;
    }
    
}
