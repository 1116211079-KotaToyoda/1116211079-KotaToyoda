using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ServiceCounterDetection : MonoBehaviour
{
    // Start is called before the first frame update
    private Transform _playerPosition;
    private ServiceCounterBehaviour _serviceCounter;
    [SerializeField] private float maxServiceCounterDistance = 0.9f;
    private bool _detected = false;
    void Start()
    {
        _playerPosition = GetComponent<Transform>();
        _serviceCounter = FindObjectOfType<ServiceCounterBehaviour>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void FixedUpdate()
    {
        float distance = Vector3.Distance(_playerPosition.position, _serviceCounter.GetServiceCounterPosition());

        if (distance <= maxServiceCounterDistance)
        {
            _detected = true;
        }
        else
        {
            _detected = false;
        }
    }

    public bool GetDetected()
    {
        return _detected;
    }
}
