using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class TableBehaviour : MonoBehaviour
{
    // Start is called before the first frame update
    private List<GameObject> _itemsOnTable;
    void Start()
    {
        _itemsOnTable = new List<GameObject>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void SetItemOnTable(GameObject item, Vector3 playerPos)
    {
        
        GameObject _item = Instantiate(item, transform);
        _itemsOnTable.Add(_item);
        switch (transform.name)
        {
            case "table-top":
                _item.transform.position = new Vector3(
                    playerPos.x >= 0 ? (int)playerPos.x + 0.5f : (int)playerPos.x - 0.5f,
                    transform.position.y
                );
                break;
            case "table-bottom":
                _item.transform.position = new Vector3(
                    playerPos.x >= 0 ? (int)playerPos.x + 0.5f : (int)playerPos.x - 0.5f,
                    transform.position.y
                );
                break;
            case "table-left":
                _item.transform.position = new Vector3(
                    transform.position.x,
                    playerPos.y >= 0 ? (int)playerPos.y + 0.5f : (int)playerPos.y - 0.5f
                );
                break;
            case "table-right" :
                _item.transform.position = new Vector3(
                    transform.position.x,
                    playerPos.y >= 0 ? (int)playerPos.y + 0.5f : (int)playerPos.y - 0.5f
                );
                break;
            case "table-center":
                if (playerPos.x < transform.position.x - transform.lossyScale.x / 2 + 0.5f||
                    transform.position.x + transform.lossyScale.x / 2 < playerPos.x)
                {
                    _item.transform.position = new Vector3(
                        playerPos.x >= 0 ? (int)playerPos.x - 0.5f : (int)playerPos.x + 0.5f,
                        transform.position.y
                    );
                }
                else
                {
                    _item.transform.position = new Vector3(
                        playerPos.x >= 0 ? (int)playerPos.x + 0.5f : (int)playerPos.x - 0.5f,
                        transform.position.y
                    );
                }
                break;
        }
        _item.transform.localScale = new Vector3(
            1.2f * _item.transform.localScale.x / transform.lossyScale.x,
            1.2f * _item.transform.localScale.y / transform.lossyScale.y
        );
    }

    public GameObject RemoveItemFromTable(Vector3 playerPos)
    {
        GameObject itemDestroyed = null;
        switch (transform.name)
        {
            case "table-top":
                itemDestroyed = DestroyItemOntable(new Vector3(
                    playerPos.x >= 0 ? (int)playerPos.x + 0.5f : (int)playerPos.x - 0.5f,
                    transform.position.y
                    ));
                break;
            case "table-bottom":
                itemDestroyed = DestroyItemOntable(new Vector3(
                    playerPos.x >= 0 ? (int)playerPos.x + 0.5f : (int)playerPos.x - 0.5f,
                    transform.position.y
                ));
                break;
            case "table-left":
                itemDestroyed = DestroyItemOntable(new Vector3(
                    transform.position.x,
                    playerPos.y >= 0 ? (int)playerPos.y + 0.5f : (int)playerPos.y - 0.5f
                ));
                break;
            case "table-right":
                itemDestroyed = DestroyItemOntable(new Vector3(
                    transform.position.x,
                    playerPos.y >= 0 ? (int)playerPos.y + 0.5f : (int)playerPos.y - 0.5f
                ));
                break;
            case "table-center":
                if (playerPos.x < transform.position.x - transform.lossyScale.x / 2 ||
                    transform.position.x + transform.lossyScale.x / 2 < playerPos.x)
                {
                    itemDestroyed = DestroyItemOntable(new Vector3(
                        playerPos.x >= 0 ? (int)playerPos.x - 0.5f : (int)playerPos.x + 0.5f,
                        transform.position.y
                    ));
                }
                else
                {
                    itemDestroyed = DestroyItemOntable(new Vector3(
                        playerPos.x >= 0 ? (int)playerPos.x + 0.5f : (int)playerPos.x - 0.5f,
                        transform.position.y
                    ));
                }
                break;
        }

        return itemDestroyed;
    }

    private GameObject DestroyItemOntable(Vector3 itemPos)
    {
        GameObject item = null;
        for (int i = 0; i < transform.childCount; i++)
        {
            if (transform.GetChild(i).transform.position != itemPos) continue;
            item = transform.GetChild(i).gameObject;
            Destroy(transform.GetChild(i).gameObject);
            return item;
        }

        return item;
    }

    private bool GetItemOnTable(Vector3 Pos)
    {
        bool itemOnTable = false;
        for (int i = 0; i < transform.childCount; i++)
        {
            if (transform.GetChild(i).transform.position != Pos) continue;
            itemOnTable = true;
            break;
        }
        
        return itemOnTable;
    }

    public bool checkNoItemOnTablePos(Vector3 playerPos)
    {
        bool itemOnPos = false;
        switch (transform.name)
        {
            case "table-top":
                itemOnPos = GetItemOnTable(new Vector3(
                    playerPos.x >= 0 ? (int)playerPos.x + 0.5f : (int)playerPos.x - 0.5f,
                    transform.position.y
                ));
                break;
            case "table-bottom":
                itemOnPos = GetItemOnTable(new Vector3(
                    playerPos.x >= 0 ? (int)playerPos.x + 0.5f : (int)playerPos.x - 0.5f,
                    transform.position.y
                ));
                break;
            case "table-left":
                itemOnPos = GetItemOnTable(new Vector3(
                    transform.position.x,
                    playerPos.y >= 0 ? (int)playerPos.y + 0.5f : (int)playerPos.y - 0.5f
                ));
                break;
            case "table-right" :
                itemOnPos = GetItemOnTable(new Vector3(
                    transform.position.x,
                    playerPos.y >= 0 ? (int)playerPos.y + 0.5f : (int)playerPos.y - 0.5f
                ));
                break;
            case "table-center":
                if (playerPos.x < transform.position.x - transform.lossyScale.x / 2 + 0.5f||
                    transform.position.x + transform.lossyScale.x / 2 < playerPos.x)
                {
                    itemOnPos = GetItemOnTable(new Vector3(
                        playerPos.x >= 0 ? (int)playerPos.x - 0.5f : (int)playerPos.x + 0.5f,
                        transform.position.y
                    ));
                }
                else
                {
                    itemOnPos = GetItemOnTable(new Vector3(
                        playerPos.x >= 0 ? (int)playerPos.x + 0.5f : (int)playerPos.x - 0.5f,
                        transform.position.y
                    ));
                }
                break;
        }
        
        return itemOnPos;
    }

    public void Reset()
    {
        foreach (Transform child in transform)
        {
            Destroy(child.gameObject);
        }
    }
}
