using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Unity.MLAgents;

public class OvenBehaviour : MonoBehaviour
{
    // Start is called before the first frame update
    private PlayerControl _player;
    private int _onionCounter = 0;
    private bool _isCooked = false;
    private bool _isCooking = false;
    private Transform _insideOven;
    private Color _onionColor;

    [SerializeField] private GameObject _onionPrefab;
    [SerializeField] private GameObject _timerPrefab;
    
    int _timerCounter = 0;
    void Start()
    {
        _player = FindObjectOfType<PlayerControl>();
        _insideOven = transform.GetChild(0);
        _onionColor = _onionPrefab.GetComponent<SpriteRenderer>().color;
    }

    

    // Update is called once per frame
    void Update()
    {
        
    }

    private void FixedUpdate()
    {
        if (_onionCounter != 3 ) return;
        if (_isCooked || _isCooking) return;
        StartCookingTimer();

    }

    //if oven is filled with three onions, start cooking 
    private void StartCookingTimer()
    {
        
        StartCoroutine(Cooking());
        onionCookingState();
        
    }

    public void setOnionInOven()
    {
        _insideOven.transform.GetChild(_onionCounter).gameObject.SetActive(true);
        _onionCounter++;
    }

    private void onionCookingState()
    {
        for (int i = 0; i < _insideOven.childCount; i++)
        {
            _insideOven.GetChild(i).gameObject.SetActive(false);
        }

        _insideOven.GetComponent<SpriteRenderer>().color = _onionColor;
    }

    public void ResetOnionInOven()
    {
        _insideOven.GetComponent<SpriteRenderer>().color = Color.black;
        _onionCounter = 0;
        _isCooked = false;
    }

    IEnumerator Cooking()
    {
        _isCooking = true;
        _timerCounter = 0;
        GameObject _timer = Instantiate(_timerPrefab, transform);
        Text _timerText = _timer.transform.GetChild(0).gameObject.GetComponent<Text>();
        
       
       for (int i = 0; i < 20; i++)
       {
           _timerCounter++;
           yield return new WaitForSeconds(0.5f);
           _timerText.text = _timerCounter.ToString();
       }
       
       Destroy(_timer);
       _isCooking = false;
       _isCooked = true;
    }

    public Vector3 GetOvenPosition()
    {
        return transform.position;
    }

    public int GetOnionCounter()
    {
        return _onionCounter;
    }

    public bool GetIsCooked()
    {
        return _isCooked;
    }

    public int GetTimerCounter()
    {
        return _timerCounter;
    }

    public void Reset()
    {
        _isCooked = false;
        _isCooking = false;
        _onionCounter = 0;
        StopAllCoroutines();
        if (transform.childCount > 1)
        {
            Destroy(transform.Find("Timer(Clone)").gameObject);
        }
        foreach (Transform child in _insideOven)
        { 
            child.gameObject.SetActive(false);
        }
        
        _insideOven.GetComponent<SpriteRenderer>().color = Color.black;
    }
    
    
}
