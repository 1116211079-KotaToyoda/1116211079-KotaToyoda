using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OnionBehaviour : MonoBehaviour
{
    // Start is called before the first frame update
    private Transform _onions;
    
    private bool _ishit = false;
    void Start()
    {
        _onions = GetComponent<Transform>();

    }

    // Update is called once per frame
    void Update()
    {
    }

    public Vector3 getPosition()
    {
        return transform.position;
    }

    public bool GetIsHit()
    {
        return _ishit;
    }
}
