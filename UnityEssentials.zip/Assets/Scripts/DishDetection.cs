using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DishDetection : MonoBehaviour
{
    // Start is called before the first frame update
    private Transform _playerPosition;
    private bool _detected = false;
    private DishTableBehaviour _dishTable;
    [SerializeField] private float maxDishDistance = 1f;
    void Start()
    {
        _playerPosition = GetComponent<Transform>();
        _dishTable = FindObjectOfType<DishTableBehaviour>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void FixedUpdate()
    {
        if (_dishTable.Equals(null)) return;
        float distance = Vector3.Distance(_playerPosition.position, _dishTable.GetDishTablePosition());

        if (distance < maxDishDistance)
        {
            _detected = true;
        }
        else
        {
            _detected = false;
        }
    }

    public bool GetDetected()
    {
        return _detected;
    }
}
