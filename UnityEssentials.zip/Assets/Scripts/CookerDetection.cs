using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CookerDetection : MonoBehaviour
{
    // Start is called before the first frame update
    private Transform _playerPosition;
    private OvenBehaviour[] _oven;
    private bool[] _detected;
    [SerializeField] private float maxOvenDistance = 1.1f;
    void Start()
    {
        _playerPosition = GetComponent<Transform>();
        _oven = FindObjectsOfType<OvenBehaviour>();
        
        _detected = new bool[_oven.Length];
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void FixedUpdate()
    {
        for (int i = 0; i < _oven.Length; i++)
        {
            float distance = Vector3.Distance(_playerPosition.position, _oven[i].GetOvenPosition());

            if (distance < maxOvenDistance)
            {
                _detected[i] = true;
            }
            else
            {
                _detected[i] = false;
            }
        }
    }

    public bool[] GetDetected()
    {
        return _detected;
    }

    public OvenBehaviour GetOven()
    {
        OvenBehaviour oven_nearest = null;
        for (int i = 0; i < _detected.Length; i++)
        {
            if(_detected[i]) oven_nearest = _oven[i];
        }
        
        return oven_nearest;
    }
    
    public bool IsNearOven()
    {
        bool isNear = false;
        foreach (bool detected in _detected)
        {   
            //if false, continue the loop
            if (!detected) continue;
            isNear = true;
        }

        return isNear;
    }

    public void ResetAllOven()
    {
        foreach (OvenBehaviour oven in _oven)
        {
            oven.Reset();
        }
    }

    public OvenBehaviour[] GetAllOven()
    {
        return _oven;
    }
}
