using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class TimerBehaviour : MonoBehaviour
{
    private Text timerText;
    private float _timerValue;
    private bool _isOver;

    private Transform _timer;
    // Start is called before the first frame update
    void Start()
    {
        _timer = transform.Find("TimerValue");
        _timerValue = 60f;
        _isOver = false;
    }

    // Update is called once per frame
    void Update()
    {
        _timerValue -= Time.deltaTime;

        if (_timerValue <= 0f) {
            _isOver = true;
        }
        
        _timer.GetComponent<Text>().text = _timerValue.ToString("00");
    }

    public bool GetIsOver()
    {
        return _isOver;
    }

    public void ResetTimer()
    {
        _timerValue = 60f;
        _isOver = false;
    }
}
