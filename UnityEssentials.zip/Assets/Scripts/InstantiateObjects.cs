using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InstantiateObjects : MonoBehaviour
{
    // Start is called before the first frame update
    [SerializeField] private GameObject player;
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        Instantiate(player, new Vector3(Random.Range(-4f,-2f), Random.Range(-3f,3f), 0), Quaternion.identity);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
