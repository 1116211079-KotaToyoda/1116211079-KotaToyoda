using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VisualObs : MonoBehaviour
{
    private Camera _cam;

    [SerializeField] private string _tagName; 
    // Start is called before the first frame update
    void Start()
    {
        _cam = GetComponent<Camera>();
        _cam.cullingMask = 1 << LayerMask.NameToLayer(_tagName); 
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
