using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ItemManagement : MonoBehaviour
{
    // Start is called before the first frame update
    private AgentControl_no_heuristic _player;
    Vector2 _playerLookingDirection;

    private GameObject _itemHolding;
    [SerializeField] private GameObject _onionPrefab;
    [SerializeField] private GameObject _dishPrefab;
    [SerializeField] private GameObject _cookedMealPrefab;
    
    
    void Start()
    {
        _player = GetComponentInParent<AgentControl_no_heuristic>();
        
    }

    // Update is called once per frame
    void Update()
    {
        _playerLookingDirection = _player.GetLookingDirection();
        float _direction_x = _playerLookingDirection.x;
        if (_playerLookingDirection == Vector2.zero) return;
        //only horizontal change matters when holding Item
        if (Math.Abs(_direction_x) != 0)
        {
            transform.localPosition = new Vector3((_direction_x / Math.Abs(_direction_x) * 0.5f), 0);
        }
    }

    public void SetItemOnHand(string itemName)
    {
        switch (itemName)
        {
            case ("Onion"):
                Debug.Log("holding onion!");
                Instantiate(_onionPrefab,transform);
                _itemHolding = _onionPrefab;
                break;
            case "Dish":
                Instantiate(_dishPrefab, transform);
                _itemHolding = _dishPrefab;
                break;
            case "CookedMeal":
                Instantiate(_cookedMealPrefab, transform);
                _itemHolding = _cookedMealPrefab;
                break;
        }
    }

    public void SetItemOnHand(GameObject item)
    {
        Debug.Log(item.name);
        switch (item.name)
        {
            case "Onion(Clone)":
                Instantiate(_onionPrefab, transform);
                _itemHolding = _onionPrefab;
                break;
            case "Dish(Clone)":
                Instantiate(_dishPrefab, transform);
                _itemHolding = _dishPrefab;
                break;
            case "CookedMeal(Clone)":
                Instantiate(_cookedMealPrefab, transform);
                _itemHolding = _cookedMealPrefab;
                break;
        }
        
    }

    public void DestroyHoldingItem()
    {
        Destroy(transform.GetChild(0).gameObject);
        _itemHolding = null;
    }

    public GameObject GetItemHolding()
    {
        return _itemHolding;
    }
    
    public void ResetItemHolder()
    {
        _itemHolding = null;
        foreach (Transform child in transform)
        {
            Destroy(child.gameObject);
        }
    }
}
