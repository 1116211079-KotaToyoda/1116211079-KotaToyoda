using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreBoardBehaviour : MonoBehaviour
{
    // Start is called before the first frame update
    private Transform _scoreValue;
    private int _scoreCounter = 0;
    
    void Start()
    {
        _scoreValue = transform.Find("ScoreValue");
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void IncrementScore()
    {
        _scoreCounter++;
        Text scoreText = _scoreValue.GetComponent<Text>();
        scoreText.text = _scoreCounter.ToString();
    }

    public void ResetScore()
    {
        _scoreCounter = 0;
        Text scoreText = _scoreValue.GetComponent<Text>();
        scoreText.text = _scoreCounter.ToString();
    }
}
