using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerObjectDetection : MonoBehaviour
{
    // Start is called before the first frame update
    private Transform _playerPosition;
    private OnionBehaviour _onion;
    private OnionBehaviour[] _onions;
    private bool _onionDetected = false;
    private bool[] _onionsDetected;
    
    [SerializeField] private float maxOnionDistance = 1.11f;
    
    void Start()
    {
        _playerPosition = GetComponent<Transform>();
        _onion = FindObjectOfType<OnionBehaviour>();
        _onions = FindObjectsOfType<OnionBehaviour>();
        _onionsDetected = new bool[_onions.Length];
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    

    private void FixedUpdate()
    {
        if(_onion.Equals(null))return;
        
        float distance = Vector3.Distance(_playerPosition.position, _onion.getPosition());
        
        //0.75 is the distance from the center of the table to the edge of the table
        if (distance < maxOnionDistance)
        {
            
            _onionDetected = true;
        }
        else
        {
            _onionDetected = false;
        }

        for (int i = 0; i < _onions.Length; i++)
        {
            distance = Vector3.Distance(_playerPosition.position, _onions[i].getPosition());
            if (distance < maxOnionDistance)
            {
                _onionsDetected[i] = true;
            }
            else
            {
                _onionsDetected[i] = false;
            }
        }
    }

    public bool getOnionDetected()
    {
        return _onionDetected;
    }

    public bool IsNearOnion()
    {
        bool onionDetected = false;
        foreach (var isNear in _onionsDetected)
        {
            if (!isNear) continue;
            onionDetected = true;
        }
        return onionDetected;
    }

    
}
