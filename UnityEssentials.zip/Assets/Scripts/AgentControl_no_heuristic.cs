using System;
using System.Collections;
using System.Collections.Generic;
using System.Numerics;
using System.Transactions;
using Unity.MLAgents;
using Unity.MLAgents.Sensors;
using Unity.MLAgents.Actuators;
using UnityEngine;
using UnityEngine.Analytics;
using Random = UnityEngine.Random;
using Vector2 = UnityEngine.Vector2;
using Vector3 = UnityEngine.Vector3;

public class AgentControl_no_heuristic : Agent
{
    private ContactFilter2D _contactFilter;
    
    private playerObjectDetection _onionDetection;
    private CookerDetection _cookerDetection;
    private DishDetection _dishDetection;
    private ServiceCounterDetection _serviceCounterDetection;
    private ItemManagement _itemManager;
    
    private TimerBehaviour _timer;
    private ScoreBoardBehaviour _scoreBoard;
    
    private SpriteRenderer _spriteRenderer;
    
    private bool _pickUpAllowed;
    private bool _hasOnion;
    private bool _hasDish;
    private bool _hasCookedMeal;
    
    private Vector2 _lookDirection;
    private float _rayDistance;
    
    List<RaycastHit2D> hits;
    
    [SerializeField] private float playerSpeed = 2.0f;
    [SerializeField] private float horizontalRayDistance = 0.5f;
    [SerializeField] private float verticalRayDistance = 1f;

    private TableBehaviour[] _tables;
    
    private int _layerMask;
    private int _tablelayerMask;

    // Start is called before the first frame update
    void Start()
    {
        _onionDetection = GetComponent<playerObjectDetection>();
        _spriteRenderer = GetComponent<SpriteRenderer>();
        _cookerDetection = GetComponent<CookerDetection>();
        _dishDetection = GetComponent<DishDetection>();
        _serviceCounterDetection = GetComponent<ServiceCounterDetection>();
        _itemManager = GetComponentInChildren<ItemManagement>();
        _scoreBoard = FindObjectOfType<ScoreBoardBehaviour>();
        _timer = FindObjectOfType<TimerBehaviour>();

        _tables = FindObjectsOfType<TableBehaviour>();
        
        _pickUpAllowed = true;
        _hasOnion = false;
        _hasDish = false;
        _hasCookedMeal = false;
        _tablelayerMask = LayerMask.NameToLayer("Table");
        
        _lookDirection = Vector2.zero;
        _contactFilter.SetLayerMask((1 << _tablelayerMask));
        hits = new List<RaycastHit2D>();

    }

    public override void OnEpisodeBegin()
    {
        ResetEnv();
        int randomInt = Random.Range(1, 100);
        

        if (randomInt <= 50)
        {
            transform.position = new Vector3(
                Random.Range(-3f,3f),
                2.25f
                );
        }
        else
        {
            transform.position = new Vector3(
                Random.Range(-3f,3f),
                -2
                );
        }
    }

    public override void OnActionReceived(ActionBuffers actions)
    {
        if (_timer.GetIsOver())
        {
            EndEpisode();
        }
        //move agent
        transform.Translate(new Vector3(actions.ContinuousActions[0] * Time.deltaTime * playerSpeed, actions.ContinuousActions[1] * Time.deltaTime * playerSpeed));

        if (actions.ContinuousActions[0] != 0 || actions.ContinuousActions[1] != 0)
        {
            _lookDirection = new Vector2(actions.ContinuousActions[2], actions.ContinuousActions[3]);
        }
        
        if (!_lookDirection.Equals(Vector2.zero))
        {
            _lookDirection.Normalize();
            detectObjectInFront();
        }
        
        //set the last input direction
        
        //change colour if interactable object nearby
        if (_onionDetection.IsNearOnion() || _cookerDetection.IsNearOven() || _dishDetection.GetDetected() || _serviceCounterDetection.GetDetected()) 
        {
            _spriteRenderer.color = Color.green;
            //
        }
        else
        {
            _spriteRenderer.color = Color.cyan;
        }

        if (actions.ContinuousActions[4] >= 0.5)
        {
            //get item
            getItem();
        }

        if (actions.ContinuousActions[5] >= 0.5)
        {
            //put item
            putItem();
        }
        //it wont draw the ray all the time because this method wont be called if no action was inputted
        Debug.DrawRay(transform.position, _lookDirection * _rayDistance, Color.red);
    }
    
    public override void CollectObservations(VectorSensor sensor)
    {
        sensor.AddObservation(_lookDirection);
        
    }

    private void detectObjectInFront()
    {
        _rayDistance = _lookDirection.x != 0 ? horizontalRayDistance : verticalRayDistance;
        int numDetected = Physics2D.Raycast(transform.position, _lookDirection, _contactFilter, hits, _rayDistance);

        if (numDetected < 2) return;
        Debug.Log("somethings wrong... more than 2 object detected!");
    }
    
    private void getItem()
    {
        
        if (_cookerDetection.IsNearOven() && _hasDish && _cookerDetection.GetOven().GetIsCooked())
        {
            _hasDish = false;
            _hasCookedMeal = true;
            _pickUpAllowed = false;
            _itemManager.DestroyHoldingItem();
            _itemManager.SetItemOnHand("CookedMeal");
            _cookerDetection.GetOven().ResetOnionInOven();
            SetReward(5.0f);
            return;
        }
        
        if (!_pickUpAllowed) return;
        
        if (_onionDetection.IsNearOnion())
        {
            
            _pickUpAllowed = false;
            _hasOnion = true;
            _itemManager.SetItemOnHand("Onion");
            SetReward(3.0f);
            return;
        }

        if (_dishDetection.GetDetected())
        {
            
            _pickUpAllowed = false;
            _hasDish = true;
            _itemManager.SetItemOnHand("Dish");
            SetReward(3.0f);
            return;
        }

        if (hits.Count > 0 && !_onionDetection.IsNearOnion() && !_serviceCounterDetection.GetDetected() &&
            !_cookerDetection.IsNearOven() && !_dishDetection.GetDetected())
        {
            GameObject table_collide = hits[0].collider.gameObject;
            GameObject itemDestroyed = table_collide.GetComponent<TableBehaviour>().RemoveItemFromTable(transform.position);

            if (itemDestroyed == null) return;
            _itemManager.SetItemOnHand(itemDestroyed);
            if (itemDestroyed.name == "Onion(Clone)")
            {
                _hasOnion = true;
                //SetReward(3.0f);
            }

            if (itemDestroyed.name == "Dish(Clone)")
            {
                _hasDish = true;
                //SetReward(3.0f);
            }

            if (itemDestroyed.name == "CookedMeal(Clone)")
            {
                _hasCookedMeal = true;
                //SetReward(5.0f);
            }
            _pickUpAllowed = false;
        }
        
        
    }

    private void putItem()
    {
        //no item in hand, go back to loop
        if (_pickUpAllowed) return;
        if (_hasOnion && _cookerDetection.IsNearOven() && _cookerDetection.GetOven()?.GetOnionCounter() < 3)
        {
            //put onion into oven if possible (it needs to be less than 3 onions to activate this if statement)
            _hasOnion = false;
            _pickUpAllowed = true;
            _itemManager.DestroyHoldingItem();
            _cookerDetection.GetOven().setOnionInOven();
            SetReward(3.0f);
            return;
        }

        if (_hasCookedMeal && _serviceCounterDetection.GetDetected())
        {
            _hasCookedMeal = false;
            _pickUpAllowed = true;
            _itemManager.DestroyHoldingItem();
            //increase score below
            _scoreBoard.IncrementScore();
            SetReward(20f);
            return;
        }

        if (!_onionDetection.IsNearOnion() && !_serviceCounterDetection.GetDetected() && !_cookerDetection.IsNearOven() && !_dishDetection.GetDetected() && hits.Count != 0)
        {
            //if not near interactable object, and raycast is detecting table object, set items on table
            GameObject table_collide = hits[0].collider.gameObject;
            if (table_collide.GetComponent<TableBehaviour>().checkNoItemOnTablePos(transform.position)) return;
            table_collide.GetComponent<TableBehaviour>().SetItemOnTable(_itemManager.GetItemHolding(),transform.position);
            _itemManager.DestroyHoldingItem();
            _pickUpAllowed = true;
            _hasOnion = false;
            _hasDish = false;
            _hasCookedMeal = false;
            
        }
        
    }
    
    public Vector2 GetLookingDirection()
    {
        return _lookDirection;
    }

    private void ResetEnv()
    {
        _lookDirection = Vector2.zero;
        _pickUpAllowed = true;
        _hasOnion = false;
        _hasDish = false;
        _hasCookedMeal = false;
        
        _timer.ResetTimer();
        _scoreBoard.ResetScore();
        _itemManager.ResetItemHolder();
        _cookerDetection.ResetAllOven();

        foreach (TableBehaviour _table in _tables)
        {
            _table.Reset();
        }
    }
}
